"""Generates a small synthetic capture (sample_capture.pcap) for offline demos."""
from scapy.all import ARP, DNS, DNSQR, ICMP, IP, TCP, UDP, Ether, Raw, wrpcap

me, router, web, dns_srv = "192.168.1.10", "192.168.1.1", "93.184.216.34", "8.8.8.8"
m_me, m_rt = "aa:bb:cc:00:00:10", "aa:bb:cc:00:00:01"
eth_out, eth_in = Ether(src=m_me, dst=m_rt), Ether(src=m_rt, dst=m_me)

pkts = [
    Ether(src=m_me, dst="ff:ff:ff:ff:ff:ff") / ARP(op=1, psrc=me, hwsrc=m_me, pdst=router),
    eth_out / IP(src=me, dst=dns_srv) / UDP(sport=51515, dport=53) / DNS(rd=1, qd=DNSQR(qname="example.com")),
    eth_out / IP(src=me, dst=web) / TCP(sport=50000, dport=80, flags="S", seq=100),
    eth_in / IP(src=web, dst=me) / TCP(sport=80, dport=50000, flags="SA", seq=500, ack=101),
    eth_out / IP(src=me, dst=web) / TCP(sport=50000, dport=80, flags="A", seq=101, ack=501),
    eth_out / IP(src=me, dst=web) / TCP(sport=50000, dport=80, flags="PA", seq=101, ack=501)
        / Raw(b"GET /index.html HTTP/1.1\r\nHost: example.com\r\nUser-Agent: demo\r\n\r\n"),
    eth_in / IP(src=web, dst=me) / TCP(sport=80, dport=50000, flags="PA", seq=501, ack=180)
        / Raw(b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n<html>Hello</html>"),
    eth_out / IP(src=me, dst=web) / TCP(sport=50001, dport=443, flags="PA") / Raw(b"\x16\x03\x01\x02\x00\x01\x00"),
    eth_out / IP(src=me, dst=dns_srv) / ICMP(type=8, code=0) / Raw(b"abcdefgh"),
]
wrpcap("sample_capture.pcap", pkts)
print(f"Wrote sample_capture.pcap with {len(pkts)} packets")
