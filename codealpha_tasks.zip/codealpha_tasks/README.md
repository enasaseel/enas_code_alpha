# CodeAlpha Cyber Security Internship – Tasks

Submission repository: **codealpha_tasks**

| Task | Folder | Description |
|---|---|---|
| Task 1 | [`task1_network_sniffer`](task1_network_sniffer) | Python/Scapy packet sniffer that parses Ethernet/ARP/IP/TCP/UDP/ICMP/DNS/HTTP |
| Task 2 | [`task2_phishing_awareness`](task2_phishing_awareness) | Interactive phishing awareness module: red flags, social engineering, real cases, quiz |
| Task 3 | [`task3_secure_coding_review`](task3_secure_coding_review) | Security audit of a Flask app with Bandit + manual review, findings report and a fixed version |

Each folder has its own README with instructions.

> ⚠️ Educational use only. Capture traffic only on networks you own or have permission to monitor, and never deploy the intentionally vulnerable app.
