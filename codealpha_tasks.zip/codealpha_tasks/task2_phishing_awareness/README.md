# Task 2 – Phishing Awareness Training

**CodeAlpha Cyber Security Internship**

An interactive, self-contained **online training module** (single `index.html`, no dependencies) that teaches how to recognise and avoid phishing.

## Contents
1. What is phishing?
2. Types: email, spear phishing, whaling, smishing, vishing, clone sites
3. How to spot a phishing email (annotated example with red flags)
4. Recognising fake websites and look-alike URLs
5. Social-engineering tactics (urgency, fear, authority, greed, curiosity, trust)
6. Real-world cases: RSA (2011), Google/Facebook invoice fraud (2013–15), Podesta email (2016), Twitter hack (2020)
7. Best practices and what to do if you clicked
8. Interactive quiz (6 questions with instant feedback and score)

## How to run
Open `index.html` in any browser. To publish it: GitHub repo → *Settings → Pages → Deploy from branch*, then share the link.

## Notes
- Works on phones and in light/dark mode.
- All example addresses are fictional (`.example` domains).
